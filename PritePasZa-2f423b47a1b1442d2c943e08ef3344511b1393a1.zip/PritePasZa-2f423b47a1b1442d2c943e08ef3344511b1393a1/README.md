# PritePasZa

i learn how to script Discord.js and node.js
from youtube "TheSourceCode"
