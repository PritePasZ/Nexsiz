# frisbee-max
For educational purposes.

Credits to Zendovo & TheSourceCode for their useful guides & tutorial on how to host a bot on Heroku.
